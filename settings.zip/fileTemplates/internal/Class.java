#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
    @author Mario Manzanarez
    @since ${DATE}
**/
public class ${NAME} {
    private static final Logger logger = LoggerFactory.getLogger(${NAME}.class);
     @Override
    public String toString() {
        return JsonObject.mapFrom(this).encodePrettily();
    }
}
